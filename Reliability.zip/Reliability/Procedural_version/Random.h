//
// Created by Timofey Dankevich on 11/12/2020.
//

#ifndef RELIABILITY_NETWORK_RANDOM_H
#define RELIABILITY_NETWORK_RANDOM_H


class Random {
public:
    static double randomNumber();

/// The method randomize a integer number between 1 and 30.
    static int randomInteger();
};

#endif //RELIABILITY_NETWORK_RANDOM_H
