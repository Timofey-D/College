//
// Created by Timofey Dankevich on 29/11/2020.
//

#ifndef RELIABILITY_NETWORK_MAIN_H
#define RELIABILITY_NETWORK_MAIN_H
#include <Graph.h>

class main {
    public:
        static void createConnection(Graph &graph);
        static void showArray(double* array, int length);
};

#endif //RELIABILITY_NETWORK_MAIN_H
